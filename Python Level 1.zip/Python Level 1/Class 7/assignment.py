a=1
b=0
while a<=10:
    b=a+b
    print(b)
    a+=1