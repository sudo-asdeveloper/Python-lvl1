a=0
while a<=20:
    print(a)
    a+=5
b=0
for b in range (0,100):
    if (b==10):
        break
    b+=1
    if (b==13):
        continue
    print(b)
#------------------------------
b=11
while b<=100:
    b+=1
    if(b==13) or (b==14):
        continue
    print(b) 
#------------------------------
c=0
while c<=50:
    c+=1
    if(c==40):
        pass
    else:
        print(c)