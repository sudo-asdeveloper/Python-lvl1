name={1:"Bat",2:"Ball",3:"Helmet",4:"Guard"}
stock={1:"50",2:"450",3:"40",4:"55"}
price={1:"5000",2:"450",3:"4000",4:"5500"}
class Inventory:

    def add_item():
        ask_id=int(input("Enter the id of the item : "))
        ask_name=input("Enter the name of the item : ")
        ask_stock=input("Enter the stock of the item : ")
        ask_price=input("Enter the price of the item : ")
        name[ask_id]=ask_name
        stock[ask_id]=ask_stock
        price[ask_price]=ask_price
        print("Items add success\n-----------------------------------------------------")
        start()

    def update_item():
        ask_upd_id=int(input("Enter the id of the item to update : "))
        ask_upd=int(input("Enter the code for update : \n1 - Name\n2 - Stock\n3 - Price\n"))
        if ask_upd=="1":
            ask_n=input("Enter the name for the item:")
            name[ask_upd_id]=ask_n
            print("Items update success\n-----------------------------------------------------")
            start()
        
        elif  ask_upd=="2":
            ask_s=input("Enter the Stock for the item:")
            stock[ask_upd_id]=ask_s
            print("Items update success\n-----------------------------------------------------")
            start()
        
        elif ask_upd=="3":
            ask_p=input("Enter the the price for the item:")
            price[ask_upd_id]=ask_p
            print("Items update success\n-----------------------------------------------------")
            start()

        else:
            print("Enter a valid code!")
            print("\n-----------------------------------------------------")
            start()
    
    def item_details():
        ask_q1=int(input("Enter the id of the item!"))
        ask_q2=input("Enter the code for see details : \n1 - Name\n2 - Stock\n3 - Price\n")
        if ask_q2=="1":
            print("\n",name[ask_q1])
            print("\n-----------------------------------------------------")
            start()
        
        elif  ask_q2=="2":
            print("\n",stock[ask_q1])
            print("\n-----------------------------------------------------")
            start()
        
        elif ask_q2=="3":
            print("\n",price[ask_q1])
            print("\n-----------------------------------------------------")
            start()

        else:
            print("Enter a valid code!")
            print("\n-----------------------------------------------------")
            start()
def start():
    ask=input("Enter the code for action :\n1 - Add Item\n2 - Update Item\n3 - Check Details\n")
    if ask=="1":
        Inventory.add_item()
    elif ask=="2":
        Inventory.update_item()
    elif ask=="3":
        Inventory.item_details()
    else:
        print("Enter a valid code!")
        print("\n-----------------------------------------------------")
        start()
start()