a=1
for i in range(1,6,1):
        print("*"*a)
        a=a+1
for i in range(a+1,1,-1):
        print("*"*a)
        a=a-1