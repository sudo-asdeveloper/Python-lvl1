a=int(input("Enter a number: "))
if a==a
print(a)