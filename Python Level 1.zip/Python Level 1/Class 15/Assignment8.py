def start():
    ask=input("Do you want to start the calculator(y/n) : ")
    while "y" in ask:
        a=input("Enter a equation : ")
        int1=0
        int2=0
        if len(a.split(" "))==3:
            int1=a.split(" ")[0]
            int2=a.split(" ")[2]
        else:
            print("Enter a valid equation!")

        try:
            int1=float(int1)
            int2=float(int2)
        except:
            print("The input should be numbers")

        if a.split(" ")[1]=="+" or a.split(" ")[1]=="-" or a.split(" ")[1]=="*" or a.split(" ")[1]=="/":
            if a.split(" ")[1]=="+":
                print(a," = ",int(a.split(" ")[0])+int(a.split(" ")[2]))
            elif a.split(" ")[1]=="-":
                print(a," = ",int(a.split(" ")[0])-int(a.split(" ")[2]))
            elif a.split(" ")[1]=="*":
                print(a," = ",int(a.split(" ")[0])*int(a.split(" ")[2]))
            elif a.split(" ")[1]=="/":
                print(a," = ",int(a.split(" ")[0])/int(a.split(" ")[2]))
        else:
            print("There is an formula error!")
    start()

start()