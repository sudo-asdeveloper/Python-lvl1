x=[1,2,3,4,5,6,7,8]

for i in range(1,len(x),1):
    a=lambda q,e :q**e
    print("Square of ",x[i]," : ",a(x[i],2))
    b=lambda r,c :r**c
    print("Cube of ",x[i]," : ",b(x[i],2))