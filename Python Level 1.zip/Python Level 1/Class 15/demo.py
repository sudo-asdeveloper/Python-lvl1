import pygame
import random

# Define constants
WIDTH = 288
HEIGHT = 512
FPS = 60
GRAVITY = 0.25
JUMP_VELOCITY = -4
PIPE_GAP = 100
PIPE_SPEED = 2
PIPE_FREQUENCY = 120

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Load assets
bird_img = pygame.image.load('bird.png')
pipe_img = pygame.image.load('pipe.png')

# Define classes
class Bird(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = bird_img
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH/2, HEIGHT/2)
        self.velocity = 0

    def update(self):
        self.velocity += GRAVITY
        self.rect.y += self.velocity

    def jump(self):
        self.velocity = JUMP_VELOCITY

class Pipe(pygame.sprite.Sprite):
    def __init__(self, y):
        super().__init__()
        self.image = pipe_img
        self.rect = self.image.get_rect()
        self.rect.bottomleft = (WIDTH, y)
        self.passed = False

    def update(self):
        self.rect.x -= PIPE_SPEED

class Score(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.score = 0
        self.font = pygame.font.Font(None, 36)
        self.image = self.font.render(str(self.score), True, (255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.topleft = (10, 10)

    def update(self):
        self.score += 1
        self.image = self.font.render(str(self.score), True, (255, 255, 255))

# Set up game objects
all_sprites = pygame.sprite.Group()
pipes = pygame.sprite.Group()
bird = Bird()
score = Score()
all_sprites.add(bird, score)

# Define game functions
def new_pipe():
    gap_y = random.randrange(HEIGHT//4, 3*HEIGHT//4)
    top_pipe = Pipe(gap_y - PIPE_GAP/2 - pipe_img.get_height())
    bottom_pipe = Pipe(gap_y + PIPE_GAP/2)
    all_sprites.add(top_pipe, bottom_pipe)
    pipes.add(top_pipe, bottom_pipe)

def draw_background():
    screen.fill((0, 128, 255))

def draw_sprites():
    all_sprites.draw(screen)

def update_sprites():
    all_sprites.update()

def draw_pipes():
    for pipe in pipes:
        screen.blit(pipe.image, pipe.rect)

def check_collisions():
    if bird.rect.bottom > HEIGHT:
        return True

    for pipe in pipes:
        if bird.rect.colliderect(pipe.rect):
            return True

    return False

def remove_offscreen_pipes():
    for pipe in pipes:
        if pipe.rect.right < 0:
            pipe.kill()

def check_passed_pipes():
    for pipe in pipes:
        if not pipe.passed and pipe.rect.right < bird.rect.left:
            pipe.passed = True
            score.update()

# Main game loop
running = True
pipe_timer = 0

while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                bird.jump()

