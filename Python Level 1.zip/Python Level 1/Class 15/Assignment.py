#1

try:
    a=int(inpt("Enter a number : "))
except:
    print("There is syntax an error!")

#2

list1=[2,3,1]
try:
    print(list1[4])
except:
    print("There is an out of index error")

#3

try:
    print(0/0)
except:
    print("There is an ZeroDivisionError")