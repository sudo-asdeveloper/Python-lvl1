a=int(input("Enter a number: "))
for i in range(1,a+1,1):
    if i*i==a:
        print("It is a perfect square!")