items=["French Fries - 1","Chilli Cheese Toast - 2","Chilli Cheese Gralic Toast - 3","Garlic Bread - 4","Garlic Bread with Cheese - 5"]
tables=[1,2,3,4,5,6,7,8,9,10]
reserved_tabeles=[]
cust_orders=[]
class Restaurant:
    def menu():
        print(items)
        start()
    
    def book_table():
        ask_tables=int(input("Enter the table number to book: "))
        if ask_tables in reserved_tabeles:
            print("The table is already booked")
            start()
        else:
            print("Table ",ask_tables," booked!")
            reserved_tabeles.append(ask_tables)
            start()
    
    def orders():
        print(items)
        ask_orders=input("Enter the food code:")
        if "1" in ask_orders:
            print("French Fries added")
            cust_orders.append("French Fries")
            start()
        elif "2" in ask_orders:
            print("Chilli Cheese Toast added")
            cust_orders.append("Chilli Cheese Toast")
            start()
        elif "3" in ask_orders:
            print("Chilli Cheese Gralic Toast added")
            cust_orders.append("Chilli Cheese Gralic Toast")
            start()
        elif "4" in ask_orders:
            print("Garlic Bread added")
            cust_orders.append("Garlic Bread")
            start()
        elif "5" in ask_orders:
            print("Garlic Bread with Cheese added")
            cust_orders.append("Garlic Bread with Cheese")
            start()
        else:
            print("Enter a valid code!")
            start()
    
    def add_menu():
        print("The current values in menu are: ",items)
        ask_items=input("Enter the item to be added : ")
        if ask_items in items:
            print("Item already in the menu")
            start()
        else:
            print(ask_items," Added to the menu")
            items.append(ask_items)
            start()
    
    def reserved_tables():
        print(reserved_tabeles)
        start()
    
    def cust_orders():
        print(cust_orders)
        start()

def start():
    ask=input("Enter the action code:\n1 - Add Item To Menu\n2 - Reserve Table\n3 - Take Customer's Orders\n4 - Menu\n5 - Table Reservations\n6 - Customer's Orders\n")
    if ask=="1":
        Restaurant.add_menu()
    elif ask=="2":
        Restaurant.book_table()
    elif ask=="3":
        Restaurant.orders()
    elif ask=="4":
        Restaurant.menu()
    elif ask=="5":
        Restaurant.reserved_tables()
    elif ask=="6":
        Restaurant.cust_orders()

start()