#the following are some commands for the terminal

#pwd (present working directory) is used to see the current directory
#cd (change directory) is used to change the current directory
#mkdir is used create a folder in the current directory
#open is used to open a file or folder

import os
import shutil
#a for append
#w for overwrites but appends adds
#r for reading the file
#x for creating a file


#b=open("D:/Python/Class 16/test.txt","a")
#b.write("\nHi this is a demo line")
#b.close()
#a=open("D:/Python/Class 16/test.txt","r")
#print(a.read())
#a.close()
#os.remove("D:/Python/Class 16/test.txt")

#d=open("D:/Python/Class 16/demo.txt","x")
#e=open("D:/Python/Class 16/demo1.txt","x")
#e.close()
#d.close()

#g="D:/Python/Class 16/demo.txt"
#d="D:/Python/Class 16/demo1.txt"

#shutil.copy(g,d) is copying the things of g to d

#shutil.copy(g,d)

#shutil.move is moving the file to other file

#shutil.move(g,d)

h="D:/Python"
print(os.listdir(h))
#the above line finds all the files and folders in the directory

f="D:\Python\Class 16\demo.txt"
z=shutil.which(f)
print(z)
#the above line finds the path of the file

