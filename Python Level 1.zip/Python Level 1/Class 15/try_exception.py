a=int(input("Enter a number : "))
b=int(input("Enter a number : "))
try: 
    print(a/b)

except ZeroDivisionError:
    print("There is an error!")

else:
    print("This is an else part!")

finally:
    print("The code is working!")

#------------------------------------------------------------------------------

#different types of errors


#1
#Exception


#Base class for all exceptions

#2	
#StopIteration

#Raised when the next() method of an iterator does not point to any object.

#3	
#SystemExit

#Raised by the sys.exit() function.

#4	
#StandardError

#Base class for all built-in exceptions except StopIteration and SystemExit.

#5	
#ArithmeticError

#Base class for all errors that occur for numeric calculation.

#6	
#OverflowError

#Raised when a calculation exceeds maximum limit for a numeric type.

#7	
#FloatingPointError

#8	
#ZeroDivisionError

#Raised when division or modulo by zero takes place for all numeric types.

#9	
#AssertionError

#Raised in case of failure of the Assert statement.

#10	
#AttributeError

#Raised in case of failure of attribute reference or assignment.

#11	
#EOFError

#Raised when there is no input from either the raw_input() or input() function and the end of file is reached.

#12	
#ImportError

#Raised when an import statement fails.

#13	
#KeyboardInterrupt


#14	
#LookupError

#Base class for all lookup errors.

#15	
#IndexError

#Raised when an index is not found in a sequence.

#16	
#KeyError

#Raised when the specified key is not found in the dictionary.

#17	
#NameError

#Raised when an identifier is not found in the local or global namespace.

#18	
#UnboundLocalError

#Raised when trying to access a local variable in a function or method but no value has been assigned to it.

#19	
#EnvironmentError

#Base class for all exceptions that occur outside the Python en
#20	
#IOError

#Raised when an input/ output operation fails, such as the print statement or the open() function when trying to open a file that does not exist.

#21	
#IOError

#Raised for operating system-related errors.

#22	
#SyntaxError

#Raised when there is an error in Python syntax.

#23	
#IndentationError

#Raised when indentation is not specified properly.

#24	
#SystemError

#Raised when the interpreter finds an internal problem, but when this error is encountered the Python interpreter does not exit