m=int(input("Enter the number of rows:"))
n=int(input("Enter the number of columns"))
j=1
i=1
for u in range(1,n+1,1):
    for k in range(1,m+1):
        print(j*i,end=" ")
        j=j+1
    print("")
    j=1
    i=i+1