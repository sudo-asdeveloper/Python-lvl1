import sqlite3
from tkinter import *
screen=Tk()
screen.geometry("500x500")

connection=sqlite3.connect("databasex.db")
#to connect or create a database named database.db

curs_er=connection.cursor()
#here, curser is used to create curser oubject.This will help to execute the quary once they are created.

#Table1="""CREATE TABLE employee_details(
#staff_number int primary key,
#staff_fname text,
#staff_lname text,
#staff_gender text,
#staff_joining varchar(10)
#)"""
#creating a table


#curs_er.execute(Table1)
#executing the quary table1




def query():
    curs_er.execute("""select * from employee_details""")
    fetch=curs_er.fetchall()
    result=""
    for i in fetch:
        result+=i[1]+" "+i[2]+"\n"
    lbl6=Label(screen,text=result)
    lbl6.grid(row=9,columnspan=2)
    connection.commit()
    


lbl1=Label(screen,text="Staff Number : ")
lbl1.grid(row=0,column=0)
staff_number=IntVar
txt1=Entry(screen,textvariable=staff_number)
txt1.grid(row=0,column=1)

lbl2=Label(screen,text="First Name : ")
lbl2.grid(row=1,column=0)
staff_fname=StringVar
txt2=Entry(screen,textvariable=staff_fname)
txt2.grid(row=1,column=1)

lbl3=Label(screen,text="Last Name : ")
lbl3.grid(row=2,column=0)
staff_lname=StringVar
txt3=Entry(screen,textvariable=staff_lname)
txt3.grid(row=2,column=1)

lbl4=Label(screen,text="Gender : ")
lbl4.grid(row=3,column=0)
staff_gender=StringVar
txt4=Entry(screen,textvariable=staff_gender)
txt4.grid(row=3,column=1)

lbl5=Label(screen,text="Date of Joining : ")
lbl5.grid(row=4,column=0)
staff_date=StringVar
txt5=Entry(screen,textvariable=staff_date)
txt5.grid(row=4,column=1)

#curs_er.execute("""insert into employee_details values(1,"Aditya","Singh","Male","26-10-2007")""")
def add():
    curs_er.execute("insert into employee_details values(:id,:fname,:lname,:gender,:doj)",
                {
                    "id":txt1.get(),
                    "fname":txt2.get(),
                    "lname":txt3.get(),
                    "gender":txt4.get(),
                    "doj":txt5.get()
                }    
                    )
    txt1.delete(0,END)
    staff_number=""
    staff_number=IntVar

    txt2.delete(0,END)
    staff_fname=""
    staff_fname=StringVar

    txt3.delete(0,END)
    staff_lname=""
    staff_lname=StringVar

    txt4.delete(0,END)
    staff_gender=""
    staff_gender=StringVar

    txt5.delete(0,END)
    staff_date=""
    staff_date=StringVar
    connection.commit()
    #to permenantly store the data


btn1=Button(screen,text="Add record to Database",command=add)
btn1.grid(row=5,columnspan=2)

btn2=Button(screen,text="Query the Database",command=query)
btn2.grid(row=6,columnspan=2)

lbl7=Label(screen,text="Id : ")
lbl7.grid(row=7, column=0)

txt6=Entry(screen,text="")
txt6.grid(row=7,column=1)
def update():
    curs_er.execute("""update employee_details set staff_number=:snumber,staff_fname=:sfname,staff_lname=:slname,staff_gender=:sgender,staff_joining=:sjoining where staff_number=:id""",{
        "snumber":toptxt1.get(),
        "sfname":toptxt2.get(),
        "slname":toptxt3.get(),
        "sgender":toptxt4.get(),
        "sjoining":toptxt5.get(),
        "id":txt6.get()
    })
def edit():
    top=Toplevel()
    top.geometry("500x500")
    top.title("Update")
    global txt6
    global toptxt1
    global toptxt2
    global toptxt3
    global toptxt4
    global toptxt5


    toplbl1=Label(top,text="Staff Number : ")
    toplbl1.grid(row=0,column=0)
    topstaff_number=IntVar
    toptxt1=Entry(top,textvariable=topstaff_number)
    toptxt1.grid(row=0,column=1)

    toplbl2=Label(top,text="First Name : ")
    toplbl2.grid(row=1,column=0)
    topstaff_fname=StringVar
    toptxt2=Entry(top,textvariable=topstaff_fname)
    toptxt2.grid(row=1,column=1)

    toplbl3=Label(top,text="Last Name : ")
    toplbl3.grid(row=2,column=0)
    topstaff_lname=StringVar
    toptxt3=Entry(top,textvariable=topstaff_lname)
    toptxt3.grid(row=2,column=1)

    toplbl4=Label(top,text="Gender : ")
    toplbl4.grid(row=3,column=0)
    topstaff_gender=StringVar
    toptxt4=Entry(top,textvariable=topstaff_gender)
    toptxt4.grid(row=3,column=1)

    toplbl5=Label(top,text="Date of Joining : ")
    toplbl5.grid(row=4,column=0)
    topstaff_date=StringVar
    toptxt5=Entry(top,textvariable=topstaff_date)
    toptxt5.grid(row=4,column=1)

    search_id=txt6.get()
    curs_er.execute("select * from employee_details where staff_number="+search_id)
    search=curs_er.fetchall()
    for i in search:
        toptxt1.insert(0,i[0])
        toptxt2.insert(0,i[1])
        toptxt3.insert(0,i[2])
        toptxt4.insert(0,i[3])
        toptxt5.insert(0,i[4])

    topbtn=Button(top,text="Update",command=update)
    topbtn.grid(row=5,column=0)


    top.mainloop()


btn3=Button(screen,text="Search",command=edit)
btn3.grid(row=8,column=0)

def dele():
    curs_er.execute("""delete from employee_details where staff_number="""+txt6.get())

btn4=Button(screen,text="Remove",command=dele)
btn4.grid(row=8,column=1)

screen.mainloop()