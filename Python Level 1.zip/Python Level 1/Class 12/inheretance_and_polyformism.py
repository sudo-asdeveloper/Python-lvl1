class person:
    def __init__(self,name,id):
        self.name=name
        self.id=id
    
    def display(self):
        print(self.name,self.id)

class employee(person):
    def __init__(self,salary,position,name,id):
        self.salary=salary
        self.position=position
        person.__init__(self,name,id)

    def display(self):
        print("Aditya")
    
    def __str__():
        return "Sakshi"

    def display1(self):
        person.display(self)
        print(self.salary,self.position)

name=employee(24000,"Manager","Rohan",1)
name.display1()
game=person("Aditya",1)
game.display()