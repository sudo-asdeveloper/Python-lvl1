class Rohan:
    def __init__(self,name,schoolinfo,sub1,sub2,sub3):
        self.name=name
        self.schoolinfo=schoolinfo
        self.sub1=sub1
        self.sub2=sub2
        self.sub3=sub3
    
    def avarage(self):
        print("The avarage marks of ",self.name," is ",((self.sub1+self.sub2+self.sub3)/3))

class WorkingStudent(Rohan):
    def __init__(self,name,schoolinfo,salary,sub1,sub2,sub3):
        self.salary=salary
        Rohan.__init__(self,name,schoolinfo,sub1,sub2,sub3)

    def pri(self):
        print("Name: ",self.name)
        print("School: ",self.schoolinfo)
        Rohan.avarage(self)
        print("Salary: ",self.salary)

game=WorkingStudent("Rohna","Euro International School",30000,97,99,98)
game.pri()
