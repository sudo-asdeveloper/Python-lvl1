from tkinter import *
from tkinter import messagebox
screen=Tk()
screen.geometry("500x500")
screen.title("Test")
m1=""
m2=""
m3=""
m4=""
m5=""
m6=""
m7=""
def info():
    global m1
    global m2
    global m3
    global m4
    global m5
    global m6
    global m7
    m1=messagebox.showinfo("Information","This is a demo information!")
    m2=messagebox.showwarning("Warning","This is a demo warning!")
    m3=messagebox.showerror("Error","This is a demo error!")
    m4=messagebox.askquestion("Question","This is a demo question!")
    m5=messagebox.askokcancel("OKCancel","This is a demo OkCancel!")
    m6=messagebox.askyesnocancel("YesNo","This is a demo YesNo!")
    m7=messagebox.askretrycancel("Retry","This is a demo retry prompt!")
    
def prnt():
    infoa=m1,"\n",m2,"\n",m3,"\n",m4,"\n",m5,"\n",m6,"\n",m7
    lbl=Label(screen,text=infoa)
    lbl.grid(row=2,column=0)

btn1=Button(text="Show Info",command=info)
btn1.grid(row=0,column=0)
btn2=Button(text="Print Info",command=prnt)
btn2.grid(row=1,column=0)
screen.mainloop()