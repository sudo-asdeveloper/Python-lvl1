from tkinter import *
from tkinter import messagebox
from PIL import Image,ImageTk
screen=Tk()
screen.geometry("500x500")
def open():
    img=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/c.jpg"))
    top=Toplevel(screen)
    top.geometry("500x500")
    lbl=Label(top,image=img)
    lbl.grid(row=0,column=0)
    btn2=Button(top,text=("Close"),command=top.destroy)
    btn2.grid(row=1,column=0)
    top.mainloop()

btn1=Button(screen,text="Open",command=open)
btn1.grid(row=0,column=0)
screen.mainloop()