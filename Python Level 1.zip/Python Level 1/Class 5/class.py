set1={'1',1,2,3,4,5,6,7,8,9,0,"Its me"}
#Set is a collection of unordered, whithout index and unchangeable values
print(set1)
print(len(set1))
print(type(set1))
for x in set1:
    print(x)
print(9 in set1)
set1.add(12345)
print(set1)
set1.remove(12345)
print(set1)
a=set1.copy()
print(a)
set2={1,"221zx","3432"}
b=set1.difference(set2)
print(b)
c=set1.union(set2)
print(c)
d=set1.issubset(set2)
print(d)
e=set1.intersection(set2)
print(e)