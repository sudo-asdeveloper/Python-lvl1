from tkinter import *
from PIL import Image,ImageTk
screen=Tk()
screen.geometry("500x500")
screen.title("Coding")
screen.iconbitmap("C:/Users/adity/Downloads/icon.ico")
img1=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/abc-removebg-preview.png"))
lbl1=Label(screen,image=img1)
lbl1.grid(row=0,column=0)
screen.mainloop()