from tkinter import *
from PIL import Image,ImageTk
assignnment=Tk()
assignnment.geometry("500x500")
num=1
def bck():
    global num
    if num==0:
        num=3
        imglbl2.grid_remove()
        imglbl3.grid_remove()
        imglbl1.grid_remove()
        imglbl4.grid(row=0,columnspan=4)
    elif num==1:
        num=0
        imglbl1.grid_remove()
        imglbl3.grid_remove()
        imglbl4.grid_remove()
        imglbl1.grid(row=0,columnspan=4)
    elif num==2:
        num=1
        imglbl1.grid_remove()
        imglbl4.grid_remove()
        imglbl3.grid_remove()
        imglbl2.grid(row=0,columnspan=4)
    elif num==3:
        num=2
        imglbl4.grid_remove()
        imglbl1.grid_remove()
        imglbl2.grid_remove()
        imglbl3.grid(row=0,columnspan=4)

def nex():
    global num
    if num==0:
        num=1
        imglbl2.grid_remove()
        imglbl3.grid_remove()
        imglbl4.grid_remove()
        imglbl1.grid(row=0,columnspan=4)
    elif num==1:
        num=2
        imglbl1.grid_remove()
        imglbl3.grid_remove()
        imglbl4.grid_remove()
        imglbl2.grid(row=0,columnspan=4)
    elif num==2:
        num=3
        imglbl1.grid_remove()
        imglbl2.grid_remove()
        imglbl4.grid_remove()
        imglbl3.grid(row=0,columnspan=4)
    elif num==3:
        num=0
        imglbl1.grid_remove()
        imglbl3.grid_remove()
        imglbl2.grid_remove()
        imglbl4.grid(row=0,columnspan=4)


a=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/avatar1834509115.jpg"))
imglbl1=Label(assignnment,image=a,height=300,width=300)
imglbl1.grid(row=0,columnspan=4)
b=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/a.jpg"))
imglbl2=Label(assignnment,image=b,height=300,width=300)
c=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/b.jpg"))
imglbl3=Label(assignnment,image=c,height=300,width=300)
d=ImageTk.PhotoImage(Image.open("C:/Users/adity/Downloads/c.jpg"))
imglbl4=Label(assignnment,image=d,height=300,width=300)
btn1=Button(text="Back",command=bck)
btn1.grid(row=1,column=1)
btn2=Button(text="Next",command=nex)
btn2.grid(row=1,column=2)
btn2=Button(text="Exit",command=assignnment.destroy)
btn2.grid(row=1,column=3)
assignnment.mainloop()