from collections import *
list1=[1,2,3,4,5,6,7,84,4,5,3,6,3,345,35364,3,5653,635,363,3]
print(Counter(list1))

#Ordered Dict-it is similar to the dictionary object where keys tries to order of insertation it means if we will override or replace the previous value
d=OrderedDict()
d["1"]="Aditya"
d["2"]="Sakshi"
#ordered dict is the another way to make a dictionary
for k,v in d.items():
    print(k,v)
#deque can remove and add in list,tuples,sets and dictionary
#append,appendleft,pop,popleft are used to add or remove from any side
#insert can insert any element at any position
c=deque([22,33,44,55,66,77,88,99])
c.append(11)
c.appendleft(00)
print(c)
c.pop()
c.popleft()
print(c)

c.insert(5,1234567890)
print(c)

print(len(c))