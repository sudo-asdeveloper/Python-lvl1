import random
def game():
    i1=random.randint(1,6)
    print("You got ",i1," on your first chance!")
    c=input("Enter 'r' to roll again")
    if c=="r":
        i2=random.randint(1,6)
        print("\nYou got ",i2," on your second chance!")
        d=input("Enter 'r' to roll again")
        if c=="r":
            i3=random.randint(1,6)
            print("\nYou got ",i3," on your second chance!")
            e=i1+i2+i3
            if e==18:
                print("\nGame Over!\nYour total score is:0")
                start()
            else:
                print("\nGame Over!\nYour total score is:",e)
                start()
        else:
            print("\nGame Over!\nYour total score is:",i1+i2+i3)
            start()
    else:
        print("\nGame Over!\nYour total score is:",i1+i2+i3)
        start()


def start():
    a=input("\nAre you ready to start the game!(y/n)")
    if a=="y":
        game()
    else:
        print("Game start cancelled by the user!")
        start()
start()
i1=0
i2=0
i3=0