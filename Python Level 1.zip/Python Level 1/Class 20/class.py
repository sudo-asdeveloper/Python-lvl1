from tkinter import *
from tkinter import filedialog
from PIL import Image,ImageTk

root=Tk()
root.geometry("500x500")

def open():
    global img
    file=filedialog.askopenfilename(initialdir="C:/Users/adity/Downloads",title=("Open a Image"),filetypes=(("PNG FILES","*.png"),("all files","*.")))
    img=ImageTk.PhotoImage(Image.open(file))
    lbl1=Label(root,image=img)
    lbl1.grid(row=1,column=0)

btn1=Button(root,text="Click",command=open)
btn1.grid(row=0,column=0)

root.mainloop()