from tkinter import *
root=Tk()
root.geometry("500x500")
value=IntVar()
scl=Scale(root,orient="vertical",from_=1,to=100,variable=value)
scl.grid(row=0,column=0)
lbl1=Label(root,text="Vertical Scaler")
lbl1.grid(row=1,column=0)
def show():
    lbl2=Label(root,text="Vertical Scale Value : "+str(value.get()))
    lbl2.grid(row=3,column=0)
btn1=Button(root,text="Display Vertical",fg="white",bg="purple",command=show)
btn1.grid(row=2,column=0)
root.mainloop()