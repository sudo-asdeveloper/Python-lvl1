from tkinter import *
from tkinter import filedialog
screen=Tk()
screen.geometry("500x500")
def save():
    type=[("All Files","*."),
          ("Python Files","*.py"),
          ("TEXT FILES","*.txt")]
    file= filedialog.asksaveasfilename(filetypes=type,defaultextension=type)

btn1=Button(screen,text="Click me",command=save)
btn1.grid(row=0,column=0)
screen.mainloop()