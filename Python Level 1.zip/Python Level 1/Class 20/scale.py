from tkinter import *

root=Tk()
root.geometry("500x500")
v1=IntVar()
scl=Scale(root,orient=HORIZONTAL,variable=v1,from_=1,to=100)
scl.grid(row=2,column=0)
def show():
    global scl
    global lbl1
    lbl1=Label(root,text=scl.get())
    lbl1.grid(row=1,column=0)
btn1=Button(root,text="Show",command=show)
btn1.grid(row=0,column=0)

root.mainloop()