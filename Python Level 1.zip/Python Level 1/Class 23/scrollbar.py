from tkinter import *
screen=Tk()
screen.geometry("500x500")
item1=['CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard','CPU','Motherboard','Cabonet','RAM','Keyboard']
lst1=Listbox(screen,width=50,height=5)
lst1.pack(side=LEFT,fill=BOTH)
scrl=Scrollbar(screen,orient=VERTICAL)
scrl.pack(side=RIGHT,fill=Y)
for item in item1:
    lst1.insert(END,*item1)
lst1.config(yscrollcommand=scrl.set)
scrl.config(command=lst1.yview)
screen.mainloop()