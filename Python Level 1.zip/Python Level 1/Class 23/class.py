from tkinter import *
screen=Tk()
screen.geometry("500x500")
item1=['CPU','Motherboard','Cabonet','RAM','Keyboard']
scrl=Scrollbar(screen,orient=VERTICAL)
scrl.pack(side=RIGHT,fill=Y)
lst1=Listbox(screen,yscrollcommand=scrl.set)
lst1.pack(fill=BOTH)

scrl.config(command=lst1.yview)
def dlt():
    lst1.delete(ANCHOR)
def slt():
    lab1=Label(screen,text=lst1.get(ANCHOR))
    lab1.pack()
btn1=Button(screen,text="DELETE",command=dlt)
for item in item1:
    lst1.insert(END,*item1)
btn1.pack()
btn2=Button(screen,text="SELECT",command=slt)
btn2.pack()
screen.mainloop()