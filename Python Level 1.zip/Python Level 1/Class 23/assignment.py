from tkinter import *
screen=Tk()
screen.geometry("250x250")
otp=Listbox(screen)
otp.pack(side=LEFT,fill=BOTH)
item=[]
a=1
for i in range (1,31,1):
    item.append("item"+str(a))
    a=a+1
otp.insert(END,*item)
scrl=Scrollbar(screen,orient=VERTICAL)
scrl.pack(side=RIGHT,fill=Y)
scrl.config(command=otp.yview)
otp.config(yscrollcommand=scrl.set)
screen.mainloop()