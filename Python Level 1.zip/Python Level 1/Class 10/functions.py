def product(val1,val2):
    print(val1*val2)

product(12,23)

def check(num1,num2):
    if (num1%num2==0):
        print("yes divisible")
    else:
        print("reaminder is not zero")

check(23,4646) 


#-----------------------------------

def evenorodd(num):
    if num%2==0:
        print("This is a even number")
    else:
        print("this is a odd number")

evenorodd(34534)