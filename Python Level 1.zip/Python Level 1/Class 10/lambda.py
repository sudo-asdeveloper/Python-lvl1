multiply= lambda a,b:a*b
print(multiply(35,235))
