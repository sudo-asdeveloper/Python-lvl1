#Question 1

def even(a):
    if a%2==0:
        print("It is a even number")
    else:
        print("It is an odd number")

b=int(input("Enter a number: "))
even(b)


#Question 2


def perfect_square(n):
    i=0
    for i in range(1,n,1):
        if i*i==n:
            print("it is a perfect square")
        else:
            i=i+1
n=int(input("Enter a number: "))
perfect_square(n)
        

#Question 3

num1=int(input("Enter first number: "))
num2=int(input("Enter second number: "))
num3=int(input("Enter third number: "))
num4=int(input("Enter forth number: "))
num5=int(input("Enter fifth number: "))
list1=[]
list1.append(num1)
list1.append(num2)
list1.append(num3)
list1.append(num4)
list1.append(num5)

def perfect_square_even(d):
    i=0
    for i in range(1,d,1):
        if i*i==d:
            if d%2==0:
                print(d)
        else:
            i=i+1
i=0
for x in range(1,5):
    f=list1[x]
    perfect_square_even(f)


#Question 4
 
d=input("Enter a Word")
e=d[::-1]
if d==e:
    print("It is a palindrome word")
else:
    print("It is not a palindrome word")


#Question 5

v=input("Enter a word")
s=input("Enter a word")
if len(v)>len(s) or len(v)==len(s):
    print(v.replace(v[0],s[0]))
else:
    print(s.replace(s[0],v[0]))

