list1=[]
list1.append(1)
print(list1)
def prime_number(a):
    if a<2:
        return False
    else:
        i=2
        while (i<a):
            if (a%i==0):
                return False
            i=i+1
        return True
print(prime_number(234))
