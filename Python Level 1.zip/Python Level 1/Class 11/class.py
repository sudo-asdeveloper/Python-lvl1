#class is a blueprint of a object consisting of functions
class banking:
    def __init__(self,name,account,balance):
        self.name=name
        self.account=account
        self.balance1=balance
    def withdrawl(self):
        amount_withdrawl=int(input("Enter the amount to be withdrawled! : "))
        if self.balance1<amount_withdrawl:
            print("Incifficient Balance!")
        else:
            self.balance1=self.balance1-amount_withdrawl
            print("Withdrawl Success!")
            print("Your remaing balance is ",self.balance1)

    def deposite(self):
        amount_deposite=int(input("Enter the amount to be deposited! : "))
        self.balance1=self.balance1+amount_deposite
        print("Deposite Success!")
        print("Your updated balance is ",self.balance1)

    def balance(self):
        print("Your balance is ",self.balance1)

customer1= banking("Aditya",234686762347,233434)
customer2= banking("Sakshi",235345234534,234535523)

customer1.withdrawl()
customer1.deposite()
customer1.balance()