class employee:
    def __init__(self,name,age,id_details,salary,position,bonus,timings):
        self.name=name
        self.age=age
        self.id_details=id_details
        self.salary=salary
        self.positon=position
        self.bonus=bonus
        self.timings=timings
    def increase_salary(self):
        print("The current salary of ",self.name," is: ",self.salary)
        increase=int(input("Enter the amount to be increased: "))
        self.salary=self.salary+increase
        print("The salary for ",self.name," has been increased to ", self.salary)
        react()
    
    def promote_position(self):
        print("The current position of ",self.name," is ",self.positon)
        promote=input("Enter the position to be promoted: ")
        self.positon=promote
        print(self.name," has been promoted to ", self.positon)
        react()
    
    def timing(self):
        print("The timing is ",self.timings)
        timi=int(input("Enter the IN time(in AM) : "))
        if timi>11:
            print("The time is too late!")
            react()
        elif timi<9:
            print("The time is too early!")
            react()
        elif timi<=11 and timi>=9:
            self.timings=str(timi)+"AM to 9PM"
            print("The updated timing for",self.name,"is" ,self.timings)
            react()
        else:
            print("Enter a valid time!")
            react()
#bonus function
    def info(self):
        print("The name of Employee: ",self.name)
        print("The age of Employee: ", self.age)
        print("The id of Employee:", self.id_details)
        print("The salary of Employee: ",self.salary)
        print("The position of Employee: ",self.positon)
        print("The bonus for the Employee: ",self.bonus)
        print("The timing for the Employee: ",self.timings)
        react()

employee1=employee("Aditya",16,1,24000,"Sales Man",1200,"9AM to 5PM")
employee2=employee("Sakshi",23,2,25000,"Sales Man",1500,"9AM to 5PM")
employee3=employee("Varsha",18,3,21000,"Sales Man",1100,"9AM to 5PM")
employee4=employee("Meghana",15,4,20000,"Sales Man",1000,"9AM to 5PM")
employee5=employee("Antim",41,5,29000,"Sales Man",1900,"9AM to 5PM")
employee6=employee("Vikram",50,6,30000,"Sales Man",2000,"9AM to 5PM")
print("Following are the codes for the Actions: \n 1. sal-INCREASING SALARY \n 2. pro-PROMOTING TO ANOTHER POSITION \n 3. tim-TIMING DETAILS \n 4. info-INFORMATION OF THE EMPLOYEE")
def react():
    act()
def act():
    action=input("Enter the action to be done: ")
    if action=="sal":
        question=input("Enter the name of the Employee: ")
        if question=="Aditya":
            employee1.increase_salary()
        elif question=="Sakshi":
            employee2.increase_salary()
        elif question=="Varsha":
            employee3.increase_salary()
        elif question=="Meghana":
            employee4.increase_salary()
        elif question=="Antim":
            employee5.increase_salary()
        elif question=="Vikram":
            employee6.increase_salary()
        else:
            print("Enter a valid name!")
    elif action=="pro":
        question=input("Enter the name of the Employee: ")
        if question=="Aditya":
            employee1.promote_position()
        elif question=="Sakshi":
            employee2.promote_position()
        elif question=="Varsha":
            employee3.promote_position()
        elif question=="Meghana":
            employee4.promote_position()
        elif question=="Antim":
            employee5.promote_position()
        elif question=="Vikram":
            employee6.promote_position()
        else:
            print("Enter a valid name!")
    elif action=="tim":
        question=input("Enter the name of the Employee: ")
        if question=="Aditya":
            employee1.timing()
        elif question=="Sakshi":
            employee2.timing()
        elif question=="Varsha":
            employee3.timing()
        elif question=="Meghana":
            employee4.timing()
        elif question=="Antim":
            employee5.timing()
        elif question=="Vikram":
            employee6.timing()
        else:
            print("Enter a valid name!")
    elif action=="info":
        question=input("Enter the name of the Employee: ")
        if question=="Aditya":
            employee1.info()
        elif question=="Sakshi":
            employee2.info()
        elif question=="Varsha":
            employee3.info()
        elif question=="Meghana":
            employee4.info()
        elif question=="Antim":
            employee5.info()
        elif question=="Vikram":
            employee6.info()
        else:
            print("Enter a valid name!")
            react()
    else:
        print("Enter a valid action!")
        react()
act()