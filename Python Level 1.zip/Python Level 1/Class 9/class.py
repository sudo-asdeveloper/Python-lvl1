import random 
list1=[21,32,321,31,423,4213,675,76]
print (min(list1))
print(max(list1))
random.shuffle(list1)
print(list1)
print (random.randint(0,99999))
print (random.random())
#0-1
print(random.choice(list1))
#Random item form the list
#Sample-It returns a list in which randomly items will come 
print(random.sample(list1,k=5))
#uniform-It gives us a random floating number
print(random.uniform(0,323))
