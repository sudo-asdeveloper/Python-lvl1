from tkinter import *
from tkinter.messagebox import *
from tkinter.filedialog import *
screen=Tk()


def feedback():
    top3=Toplevel()
    top3.title("Feedback")
    lbl1=Label(top3,text="Feedback",font=("Aerial",20,"bold"))
    lbl1.grid(row=0,column=0)
    txt_box1=Text(top3,height=10,width=50)
    txt_box1.grid(row=1,column=0)
    lbl2=Label(top3,text=("Feedback Sent!"))
    def cllk():
        lbl2.grid(row=3,column=0)
    btn1=Button(top3,text="Send",command=cllk)
    btn1.grid(row=2,column=0)
    top3.mainloop()

def lis():
    top2=Toplevel()
    top2.title("License")
    lbl1=Label(top2,text="License",font=("Aerial",20,"bold"))
    lbl1.grid(row=0,column=0)
    lbl2=Label(top2,text="A license (or licence) is an official permission or permit to do, use, or own something (as well as the document of that permission or permit).")
    lbl2.grid(row=1,column=0)
    top2.mainloop()

def upd():
    top1=Toplevel()
    top1.title("Check for Updates")
    lbl1=Label(top1,text="Check for Updates",font=("Aerial",20,"bold"))
    lbl1.grid(row=0,column=0)
    lbl2=Label(top1,text="Current version: 1.0")
    lbl2.grid(row=1,column=0)
    lbl3=Label(top1,text="Already the latest version!")
    def clk():
        lbl3.grid(row=3,column=0)
    btn=Button(top1,text="Check",command=clk)
    btn.grid(row=2,column=0)
    top1.mainloop()
def open():
    file = askopenfile(mode ='r', filetypes =[('Text Document', '*.txt')])
    if file is not None:
        txt_box.delete("1.0","end")
# txt_box.delete("1.0","end") is used to clear the text box
        content = file.read()
        txt_box.insert(INSERT,content)
# content = file.read()   txt_box.insert(INSERT,content)   is used insert the content of the text file to the text box


def save():
    type1=[("All Files","*.*"),("Text Documents","*.txt")]
    file1=asksaveasfile(filetypes=type1,defaultextension=type1)

def saveas():
    type=[("All Files","*.*"),
          ("Text Documents","*.txt")]
    file=asksaveasfile(filetypes=type,defaultextension=type)

def new():
    def feedback():
        top3=Toplevel()
        top3.title("Feedback")
        lbl1=Label(top3,text="Feedback",font=("Aerial",20,"bold"))
        lbl1.grid(row=0,column=0)
        txt_box1=Text(top3,height=10,width=50)
        txt_box1.grid(row=1,column=0)
        lbl2=Label(top3,text=("Feedback Sent!"))
        def cllk():
            lbl2.grid(row=3,column=0)
        btn1=Button(top3,text="Send",command=cllk)
        btn1.grid(row=2,column=0)
        top3.mainloop()

    def lis():
        top2=Toplevel()
        top2.title("License")
        lbl1=Label(top2,text="License",font=("Aerial",20,"bold"))
        lbl1.grid(row=0,column=0)
        lbl2=Label(top2,text="A license (or licence) is an official permission or permit to do, use, or own something (as well as the document of that permission or permit).")
        lbl2.grid(row=1,column=0)
        top2.mainloop()

    def upd():
        top1=Toplevel()
        top1.title("Check for Updates")
        lbl1=Label(top1,text="Check for Updates",font=("Aerial",20,"bold"))
        lbl1.grid(row=0,column=0)
        lbl2=Label(top1,text="Current version: 1.0")
        lbl2.grid(row=1,column=0)
        lbl3=Label(top1,text="Already the latest version!")
        def clk():
            lbl3.grid(row=3,column=0)
        btn=Button(top1,text="Check",command=clk)
        btn.grid(row=2,column=0)
        top1.mainloop()

    def open():
        open1=askopenfilename(initialdir="C:/Users/adity/OneDrive/Documents",filetypes=[("All Files","*.*"),("Text Documents","*.txt")],)
        file1=open(open1,"r")
        txt_box.insert(file1.read())
        file1.close()
    
    def save():
        type1=[("Text Documents","*.txt")]
        file1=asksaveasfile(filetypes=type,defaultextension=type)

    def saveas():
        type=[("All Files","*.*"),
          ("Text Documents","*.txt")]
        file=asksaveasfilename(filetypes=type,defaultextension=type)
        
    def exit():
        screen.destroy()

    top=Toplevel()
    top.geometry("500x500")
    top.title("Notepad")
    men=Menu(screen)
    m1=Menu(men,tearoff=0)
    m1.add_command(label="Open",command=open)
    m1.add_command(label="Save",command=save)
    m1.add_command(label="Save as",command=saveas)
    m1.add_separator()
    m1.add_command(label="Exit",command=exit)
    men.add_cascade(label="File",menu=m1)
    m2=Menu(men,tearoff=0)
    m2.add_command(label="Undo")
    m2.add_separator()
    m2.add_command(label="Cut")
    m2.add_command(label="Copy")
    m2.add_command(label="Paste")
    m2.add_separator()
    m2.add_command(label="Find")
    m2.add_command(label="Replace")
    m2.add_command(label="Select All")
    men.add_cascade(label="Edit",menu=m2)
    m3=Menu(men,tearoff=0)
    m3.add_command(label="Check Updates",command=upd)
    m3.add_command(label="Liscence",command=lis)
    m3.add_command(label="Feedback",command=feedback)
    men.add_cascade(label="Help",menu=m3)
    top.config(menu=men)
    txt_box=Text(top,width=50,height=50)
    txt_box.pack(fill=BOTH)
    top.mainloop()



def close():
    new()
    screen.quit()

def exit():
    screen.destroy()


screen.geometry("500x500")
screen.title("Notepad")


txt_box=Text(screen,width=50,height=50,undo=TRUE)
txt_box.pack(fill=BOTH)

def undo():
    var1=txt_box.get()


men=Menu(screen)
m1=Menu(men,tearoff=0)
m1.add_command(label="Open",command=open)
m1.add_command(label="New",command=new)
m1.add_command(label="Save",command=save)
m1.add_command(label="Save as",command=saveas)
m1.add_separator()
m1.add_command(label="Close",command=close)
m1.add_command(label="Exit",command=exit)
men.add_cascade(label="File",menu=m1)
m2=Menu(men,tearoff=0)
m2.add_command(label="Undo",command=undo)
m2.add_separator()
m2.add_command(label="Cut",command=lambda:screen.focus_get.event_generate("<<Cut>>"))
m2.add_command(label="Copy",command=lambda:screen.focus_get.event_generate("<<Copy>>"))
m2.add_command(label="Paste",command=lambda:screen.focus_get.event_generate("<<Paste>>"))
m2.add_separator()
m2.add_command(label="Find")
m2.add_command(label="Replace")
m2.add_command(label="Select All")
men.add_cascade(label="Edit",menu=m2)
m3=Menu(men,tearoff=0)
m3.add_command(label="Check Updates",command=upd)
m3.add_command(label="Liscence",command=lis)
m3.add_command(label="Feedback",command=feedback)
men.add_cascade(label="Help",menu=m3)
screen.config(menu=men)

    

screen.mainloop()