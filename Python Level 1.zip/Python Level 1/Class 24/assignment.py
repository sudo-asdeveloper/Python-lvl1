list1=[23, 65, 19, 90]
list2=[]
#position1=1
#position2=3
var1=0
var2=0
var3=0
var4=0
function_var=0


def swap():
    global var1
    global var2
    global var3
    global var4
    global function_var
    print("List before swap : ",list1)
    var1=list1[0]
    var2=list1[1]
    var3=list1[2]
    var4=list1[3]
    function_var=list1[0]
    var1=var3
    var3=function_var
    list2.append(var1)
    list2.append(var2)
    list2.append(var3)
    list2.append(var4)
    print("List after swap : ",list2)


a=input("Do you want to do it?")
if a.upper()=="YES":
    swap()
else:
    print("The action is disabled!")