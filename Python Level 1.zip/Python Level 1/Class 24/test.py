from tkinter import *
top3=Toplevel()
top3.title("Feedback")
lbl1=Label(top3,text="Feedback",font=("Aerial",20,"bold"))
lbl1.grid(row=0,column=0)
txt_box1=Text(top3,height=10,width=50)
txt_box1.grid(row=1,column=0)
lbl2=Label(top3,text=("Feedback Sent!"))
def cllk():
    lbl2.grid(row=3,column=0)
btn1=Button(top3,text="Send",command=cllk)
btn1.grid(row=2,column=0)
top3.mainloop()