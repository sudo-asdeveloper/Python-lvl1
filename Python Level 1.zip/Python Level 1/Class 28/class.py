from tkinter import *
import mysql.connector
import csv
import pandas as pd


connection=mysql.connector.connect(
    host="localhost",
    user="Aditya Singh",
    password="adityasingh1",
)

con=connection.cursor()

database=con.execute("create database if not exists databse")

con.execute("show databases")
for d in con:
    print(d)
con.execute("use databse")

#table1="""create table if not exists crm(
#customer_fname text,
#customer_lname text,
#customer_address1 text,
#customer_address2 text,
#customer_city text,
#customer_state text,
#customer_zip int,
#customer_country text,
#customer_phone int,
#customer_email varchar(25),
#customer_pmethod text,
#customer_dcode text,
#customer_ppaid int
#)"""
#con.execute(table1)

screen=Tk()
screen.title("Database")
screen.geometry("500x500")
lbl1=Label(screen,text="Codevidhya Customer Database",font=("aerial",10,"bold"))
lbl1.grid(row=0,columnspan=1)
lbl2=Label(screen,text="First Name : ")
lbl2.grid(row=1,column=0)
txt1=Entry(screen)
txt1.grid(row=1,column=1)
lbl3=Label(screen,text="Last Name : ")
lbl3.grid(row=2,column=0)
txt2=Entry(screen)
txt2.grid(row=2,column=1)
lbl4=Label(screen,text="Address 1 : ")
lbl4.grid(row=3,column=0)
txt3=Entry(screen)
txt3.grid(row=3,column=1)
lbl5=Label(screen,text="Address 2 : ")
lbl5.grid(row=4,column=0)
txt4=Entry(screen)
txt4.grid(row=4,column=1)
lbl6=Label(screen,text="City : ")
lbl6.grid(row=5,column=0)
txt5=Entry(screen)
txt5.grid(row=5,column=1)
lbl7=Label(screen,text="State : ")
lbl7.grid(row=6,column=0)
txt6=Entry(screen)
txt6.grid(row=6,column=1)
lbl8=Label(screen,text="Zipcode : ")
lbl8.grid(row=7,column=0)
txt7=Entry(screen)
txt7.grid(row=7,column=1)
lbl9=Label(screen,text="Country : ")
lbl9.grid(row=8,column=0)
txt8=Entry(screen)
txt8.grid(row=8,column=1)
lbl10=Label(screen,text="Phone Number : ")
lbl10.grid(row=9,column=0)
txt9=Entry(screen)
txt9.grid(row=9,column=1)
lbl11=Label(screen,text="Email Address : ")
lbl11.grid(row=10,column=0)
txt10=Entry(screen)
txt10.grid(row=10,column=1)
lbl12=Label(screen,text="Payment Method : ")
lbl12.grid(row=11,column=0)
txt11=Entry(screen)
txt11.grid(row=11,column=1)
lbl13=Label(screen,text="Discount Code : ")
lbl13.grid(row=12,column=0)
txt12=Entry(screen)
txt12.grid(row=12,column=1)
lbl14=Label(screen,text="Price Paid : ")
lbl14.grid(row=13,column=0)
txt13=Entry(screen)
txt13.grid(row=13,column=1)
lbl14=Label(screen,text="Search by ")
lbl14.grid(row=14,column=0)
var=StringVar()
opt=['phone','lastname']
lbl15=OptionMenu(screen,var,*opt)
lbl15.grid(row=15,column=0)
txt16=Entry(screen)
txt16.grid(row=15,column=1)

def insert():
    qur1=("insert into crm(customer_fname,customer_lname,customer_address1,customer_address2,customer_city,customer_state,customer_zip,customer_country,customer_phone,customer_email,customer_pmethod,customer_dcode,customer_ppaid) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
    tpl1=(txt1.get(),txt2.get(),txt3.get(),txt4.get(),txt5.get(),txt6.get(),txt7.get(),txt8.get(),txt9.get(),txt10.get(),txt11.get(),txt12.get(),txt13.get())
    con.execute(qur1,tpl1)
    connection.commit()


btn1=Button(screen,text="Add Customer to Database",command=insert)
btn1.grid(row=16,column=0)

def clear():
    txt1.delete(0,END)
    txt2.delete(0,END)
    txt3.delete(0,END)
    txt4.delete(0,END)
    txt5.delete(0,END)
    txt6.delete(0,END)
    txt7.delete(0,END)
    txt8.delete(0,END)
    txt9.delete(0,END)
    txt10.delete(0,END)
    txt11.delete(0,END)
    txt12.delete(0,END)
    txt13.delete(0,END)


btn2=Button(screen,text="Clear Fields",command=clear)
btn2.grid(row=16,column=1)


def lst():
    global val
    global var
    global txt16
    val=txt16.get()
    if var.get()=='phone':
        con.execute("select * from crm where customer_phone="+val)
    elif var.get()=='lastname':
        con.execute("select * from crm where customer_lname='%s'"%(val))
    result=con.fetchall()
    top=Toplevel()
    top.geometry("500x500")
    lbl20=Label(top,text="Codevidhya Customer Database",font=("aerial",10,"bold"))
    lbl20.grid(row=0,columnspan=1)
    lbl21=Label(top,text="First Name : ")
    lbl21.grid(row=1,column=0)
    txt20=Entry(top)
    txt20.grid(row=1,column=1)
    lbl23=Label(top,text="Last Name : ")
    lbl23.grid(row=2,column=0)
    txt22=Entry(top)
    txt22.grid(row=2,column=1)
    lbl24=Label(top,text="Address 1 : ")
    lbl24.grid(row=3,column=0)
    txt23=Entry(top)
    txt23.grid(row=3,column=1)
    lbl25=Label(top,text="Address 2 : ")
    lbl25.grid(row=4,column=0)
    txt24=Entry(top)
    txt24.grid(row=4,column=1)
    lbl26=Label(top,text="City : ")
    lbl26.grid(row=5,column=0)
    txt25=Entry(top)
    txt25.grid(row=5,column=1)
    lbl27=Label(top,text="State : ")
    lbl27.grid(row=6,column=0)
    txt26=Entry(top)
    txt26.grid(row=6,column=1)
    lbl28=Label(top,text="Zipcode : ")
    lbl28.grid(row=7,column=0)
    txt27=Entry(top)
    txt27.grid(row=7,column=1)
    lbl29=Label(top,text="Country : ")
    lbl29.grid(row=8,column=0)
    txt28=Entry(top)
    txt28.grid(row=8,column=1)
    lbl210=Label(top,text="Phone Number : ")
    lbl210.grid(row=9,column=0)
    txt29=Entry(top)
    txt29.grid(row=9,column=1)
    lbl211=Label(top,text="Email Address : ")
    lbl211.grid(row=10,column=0)
    txt210=Entry(top)
    txt210.grid(row=10,column=1)
    lbl212=Label(top,text="Payment Method : ")
    lbl212.grid(row=11,column=0)
    txt211=Entry(top)
    txt211.grid(row=11,column=1)
    lbl213=Label(top,text="Discount Code : ")
    lbl213.grid(row=12,column=0)
    txt212=Entry(top)
    txt212.grid(row=12,column=1)
    lbl214=Label(top,text="Price Paid : ")
    lbl214.grid(row=13,column=0)
    txt213=Entry(top)
    txt213.grid(row=13,column=1)
    for i in result:
        txt20.insert(0,i[0])
        txt22.insert(0,i[1])
        txt23.insert(0,i[2])
        txt24.insert(0,i[3])
        txt25.insert(0,i[4])
        txt26.insert(0,i[5])
        txt27.insert(0,i[6])
        txt28.insert(0,i[7])
        txt29.insert(0,i[8])
        txt210.insert(0,i[9])
        txt211.insert(0,i[10])
        txt212.insert(0,i[11])
        txt213.insert(0,i[12])
    connection.commit()
    top.mainloop()

btn3=Button(screen,text="List Customer",command=lst)
btn3.grid(row=17,column=0)

def upd():
    global val
    global txt16
    val=txt16.get()
    con.execute("select * from crm where customer_phone="+val)
    result=con.fetchall()
    top=Toplevel()
    top.geometry("500x500")
    lbl20=Label(top,text="Codevidhya Customer Database",font=("aerial",10,"bold"))
    lbl20.grid(row=0,columnspan=1)
    lbl21=Label(top,text="First Name : ")
    lbl21.grid(row=1,column=0)
    txt20=Entry(top)
    txt20.grid(row=1,column=1)
    lbl23=Label(top,text="Last Name : ")
    lbl23.grid(row=2,column=0)
    txt22=Entry(top)
    txt22.grid(row=2,column=1)
    lbl24=Label(top,text="Address 1 : ")
    lbl24.grid(row=3,column=0)
    txt23=Entry(top)
    txt23.grid(row=3,column=1)
    lbl25=Label(top,text="Address 2 : ")
    lbl25.grid(row=4,column=0)
    txt24=Entry(top)
    txt24.grid(row=4,column=1)
    lbl26=Label(top,text="City : ")
    lbl26.grid(row=5,column=0)
    txt25=Entry(top)
    txt25.grid(row=5,column=1)
    lbl27=Label(top,text="State : ")
    lbl27.grid(row=6,column=0)
    txt26=Entry(top)
    txt26.grid(row=6,column=1)
    lbl28=Label(top,text="Zipcode : ")
    lbl28.grid(row=7,column=0)
    txt27=Entry(top)
    txt27.grid(row=7,column=1)
    lbl29=Label(top,text="Country : ")
    lbl29.grid(row=8,column=0)
    txt28=Entry(top)
    txt28.grid(row=8,column=1)
    lbl210=Label(top,text="Phone Number : ")
    lbl210.grid(row=9,column=0)
    txt29=Entry(top)
    txt29.grid(row=9,column=1)
    lbl211=Label(top,text="Email Address : ")
    lbl211.grid(row=10,column=0)
    txt210=Entry(top)
    txt210.grid(row=10,column=1)
    lbl212=Label(top,text="Payment Method : ")
    lbl212.grid(row=11,column=0)
    txt211=Entry(top)
    txt211.grid(row=11,column=1)
    lbl213=Label(top,text="Discount Code : ")
    lbl213.grid(row=12,column=0)
    txt212=Entry(top)
    txt212.grid(row=12,column=1)
    lbl214=Label(top,text="Price Paid : ")
    lbl214.grid(row=13,column=0)
    txt213=Entry(top)
    txt213.grid(row=13,column=1)
    def updat():
       con.execute("update crm set customer_fname=:fname,customer_lname:lname,customer_address1:address1,customer_address2:address2,customer_city:city,customer_state:state,customer_zip:zip,customer_country:country,customer_phone:phone,customer_email:email,customer_pmethod:pmethod,customer_dcode:dcode,customer_ppaid:ppaid",{
           "fname":txt20.get(),
           "lname":txt22.get(),
           "address1":txt23.get(),
           "address2":txt24.get(),
           "city":txt25.get(),
           "state":txt26.get(),
           "zip":txt27.get(),
           "country":txt28.get(),
           "phone":txt29.get(),
           "email":txt210.get(),
           "pmethod":txt211.get(),
           "dcode":txt212.get(),
           "ppaid":txt213.get()
       })
    btn5=Button(top,text="Update",command=updat)
    btn5.grid(row=14,column=0)
    for i in result:
        txt20.insert(0,i[0])
        txt22.insert(0,i[1])
        txt23.insert(0,i[2])
        txt24.insert(0,i[3])
        txt25.insert(0,i[4])
        txt26.insert(0,i[5])
        txt27.insert(0,i[6])
        txt28.insert(0,i[7])
        txt29.insert(0,i[8])
        txt210.insert(0,i[9])
        txt211.insert(0,i[10])
        txt212.insert(0,i[11])
        txt213.insert(0,i[12])
    connection.commit()
    top.mainloop()

btn4=Button(screen,text="Search/Edit Customers",command=upd)
btn4.grid(row=17,column=1)

def exp():
    global result
    con.execute("select * from crm")
    with open("file.csv","w",newline="") as csvfile:
        csv_writer=csv.writer(csvfile)
        csv_writer.writerow([i[0] for i in con.description])
        csv_writer.writerows(con)

btn5=Button(screen,text="Fetch Data",command=exp)
btn5.grid(row=18,column=0)
screen.mainloop()