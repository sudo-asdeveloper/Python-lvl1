a=int(input("Enter a value:"))
print(a[::-1])