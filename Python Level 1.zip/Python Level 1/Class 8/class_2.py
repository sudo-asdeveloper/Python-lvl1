a="password"
b=""
while(b!=a):
    b=input("Enter the password:")
    c=""
    print(c,b)
    c=b
print("password is correct!")