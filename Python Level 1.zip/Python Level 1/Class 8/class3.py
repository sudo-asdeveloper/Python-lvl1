for i in range(2,61,2):
    a=(i**3)
    print(a)