a=int(input("Enter a value"))
b=input("Enter your operator")
b=b.lower()
c=int(input("Enter your second number"))
if b=="+":
    d=a+c
    print(a,"+",c,"=",d)
elif b=="-":
    d=a-c
    print(a,"-",c,"=",d)
elif b=="*":
    d=a*c
    print(a,"*",c,"=",d)
elif b=="/":
    d=a/c
    print(a,"/",c,"=",d)
elif b=="%":
    d=a%c
    print(a,"%",c,"=",d)
elif b=="**":
    d=a**c
    print(a,"**",c,"=",d)
elif b=="cancel":
    print("Thanks for calculating with us!")
