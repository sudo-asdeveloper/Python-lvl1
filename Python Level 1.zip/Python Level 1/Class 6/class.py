d1 = {'k1':[{'nest_key':['this is deep',['hello']]}]}
d = {'k1':[1,2,{'k2':['this is tricky',{'tough':[1,2,['hello']]}]}]}
#--------------------------------------------------
a=int(input("Enter the First number:"))
b=int(input("Enter the Second number:"))
c=int(input("Enter the Third number:"))
if (a>b):
    print("a is greater than b")
elif (b>c):
    d=b+c
    print("The new number is: ",d)
elif (c>a):
    print("c is greater than a")
else:
    print("Invalid")
d=input("Enter a Color")
if (d=="Red") or (d=="red"):
    print("Stop")
elif (d=="Yellow") or (d=="yellow"):
    print("It is going to be red")
elif (d=="Green") or (d=="green"):
    print("You are free to move")
else:
    print("Enter a valid color!")