#Switch is a alternate way to use multiple conditions
a=int(input("Enter a value"))
match a:
    case 1:
        print("Case 1 is maching")
    case 3:
        print("Case 3 is maching")
    case 21:
        print("Case 21 is matching")
    case _:
        print("None of then is matching")