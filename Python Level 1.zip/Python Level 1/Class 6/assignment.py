a=input("Enter your Team name:")
b=int(input("Enter your Team code:"))
a.upper()
if (a=='A') and (b==1999):
    print('There is a traitor in team B. Find him without letting the team know cause it can be anyone.')
elif (a=='B') and (b==2422):
    print('The president is in danger. Keep watch on him secretly.')
elif (a=='C') and (b==1832):
    print('There is a traitor in team A. He is off guard for now because of wrong information. This is the best chance to catch him.')
elif (a=='D') and (b==3943):
    print('Assassinate the minister.')
else:
    print('Intruder Alert!')