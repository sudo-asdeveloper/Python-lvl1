from tkinter import *
qa1="Tungstin"
qa2="Red"
qa3="Hyperopia"
qa4="Plesenta"
qa5="Small Intestine"
score=0

def submit():
    global score
    global qa1
    global qa2
    global qa3
    global qa4
    global qa5
    score=0
    if qans1.get()==qa1:
        score=score+1
    if qans2.get()==qa2:
        score=score+1
    if qans3.get()==qa2:
        score=score+1
    if qans4.get()==qa2:
        score=score+1
    if qans5.get()==qa5:
        score=score+1
        sc="Your score is "+str(score)
        cor=Label(quiz,text=sc,font=("aerial",10,"bold"),fg="green")
        cor.grid(row=17,column=0)
    else:
        sc="Your score is "+str(score)
        cor=Label(quiz,text=sc,font=("aerial",10,"bold"),fg="green")
        cor.grid(row=17,column=0)

quiz=Tk()
quiz.title("Quiz")
quiz.geometry("500x500")
lbl=Label(quiz,text="Science Quiz",font=("Impact",30),width=24)
lbl.grid(row=0,column=0)
decor1=Label(quiz,text="_______________________________________________________",width=24)
decor1.grid(row=1,column=0)
q1=Label(quiz,text="Q1. Which is the wire used in filament of a bulb?",font=("aerial",10,"bold"))
q1.grid(row=2,column=0)
qans1=StringVar()
ans1=Entry(quiz,width=30,textvariable=qans1)
ans1.grid(row=3,column=0)
decor2=Label(quiz,text="_______________________________________________________",width=24)
decor2.grid(row=4,column=0)
q2=Label(quiz,text="Q2. Which color is having the maximum wavelength?",font=("aerial",10,"bold"))
q2.grid(row=5,column=0)
qans2=StringVar()
ans2=Entry(quiz,width=30,textvariable=qans2)
ans2.grid(row=6,column=0)
decor3=Label(quiz,text="_______________________________________________________",width=24)
decor3.grid(row=7,column=0)
q3=Label(quiz,text="Q3. What is the disease when a person has farsightness?",font=("aerial",10,"bold"))
q3.grid(row=8,column=0)
qans3=StringVar()
ans3=Entry(quiz,width=30,textvariable=qans3)
ans3.grid(row=9,column=0)
decor4=Label(quiz,text="_______________________________________________________",width=24)
decor4.grid(row=10,column=0)
q4=Label(quiz,text="Q4. What provides nutrition to a unborn baby?",font=("aerial",10,"bold"))
q4.grid(row=11,column=0)
qans4=StringVar()
ans4=Entry(quiz,width=30,textvariable=qans4)
ans4.grid(row=12,column=0)
decor5=Label(quiz,text="_______________________________________________________",width=24)
decor5.grid(row=13,column=0)
q5=Label(quiz,text="Q5. Where is complete digestion completed?",font=("aerial",10,"bold"))
q5.grid(row=14,column=0)
qans5=StringVar()
ans5=Entry(quiz,width=30,textvariable=qans5)
ans5.grid(row=15,column=0)
decor6=Label(quiz,text="_______________________________________________________",width=24)
decor6.grid(row=16,column=0)
sbt=Button(quiz,text="Submit",font=("Aerial",14,"bold"),command=submit)
sbt.grid(row=18,column=0)

quiz.mainloop()