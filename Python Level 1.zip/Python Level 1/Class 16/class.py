from tkinter import *

screen=Tk()
screen.title("window")
screen.geometry("500x500")
label1=Label(screen, text="Hi I am Text")
label1.grid(row=0,column=0)
btn1=Button(screen,text="Button1")
btn1.grid(row=1,column=0)
txt1=Entry(screen)
txt1.grid(row=2,column=0)
screen.mainloop()

#screen.place(relx=0.5,rely=0.5)
#