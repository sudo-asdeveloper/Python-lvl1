

from tkinter import *
log=Tk()
log.geometry("750x500")
txt4=Label(log,text="Enter a valid details!",font=("Aerial",9,"bold"),fg="red")
txt5=Label(log,text="Login Success!",font=("Aerial",9,"bold"))
txt6=Label(log,text="Incorrect Password!",font=("Aerial",9,"bold"),fg="red")
def login():
    if user.get()=="Username":
        if passw.get()=="Password":
            txt4.grid_remove()
            txt5.grid(row=8,column=1)
            txt6.grid_remove()
        else:
          txt4.grid_remove()
          txt5.grid_remove()  
          txt6.grid(row=8,column=1)
    else:
        txt4.grid(row=8,column=1)
        txt5.grid_remove()
        txt6.grid_remove()

txt1=Label(log,text="Login Page",font=("Impact",30),width=37,height=2)
txt1.grid(row=0,column=1)
decor1=Label(log,text="______________________________________________________")
decor1.grid(row=1,columnspan=3)
txt2=Label(log,text="Username:",font=("Aerial",15,"bold"))
txt2.grid(row=2,column=1)
user=StringVar()
username=Entry(log,width=30,textvariable=user)
username.grid(row=3,column=1)
txt3=Label(log,text="Password:",font=("Aerial",15,"bold"))
txt3.grid(row=4,column=1)
passw=StringVar()
password=Entry(log,width=30,textvariable=passw)
password.grid(row=5,column=1)
login_btn=Button(log,text="Login",font=("Aerial",13,"bold"),command=login)
login_btn.grid(row=6,column=1)
decor2=Label(log,text="______________________________________________________")
decor2.grid(row=7,columnspan=3)
log.mainloop()
