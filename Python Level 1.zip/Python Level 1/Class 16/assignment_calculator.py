from tkinter import *
expression=""
pre=""
def press(no):
    global expression
    pre=expression
    expression=expression+str(no)
    a.set(expression)

def calculation():
    global expression
    result=eval(expression)
    a.set(result)


def dele():
    global expression
    pre=expression
    expression=expression+str("")
    a.set(expression)

calc=Tk()
calc.title("Calculator")
calc.geometry("500x500")
a=StringVar()
txt1=Entry(calc,font=("Aerial",18),justify=RIGHT,textvariable=a)
txt1.bind("<Key>",lambda e:"break")
txt1.grid(columnspan=4, ipadx=5)
btn1=Button(calc,text="%",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("%"))
btn1.grid(row=1,column=0)
btn2=Button(calc,text="CE",width=5,height=2,bg="white",font=("Aerial",13),command=dele)
btn2.grid(row=1,column=1)
btn3=Button(calc,text="C",width=5,height=2,bg="white",font=("Aerial",13),command=dele)
btn3.grid(row=1,column=2)
btn4=Button(calc,text="<-",width=5,height=2,bg="#1c81d9",fg="white",font=("Aerial",13,"bold"),command=dele)
btn4.grid(row=1,column=3)
btn5=Button(calc,text="1/x",width=5,height=2,bg="white",font=("Aerial",13))
btn5.grid(row=2,column=0)
btn6=Button(calc,text="x^2",width=5,height=2,bg="white",font=("Aerial",13))
btn6.grid(row=2,column=1)
btn7=Button(calc,text="3√x",width=5,height=2,bg="white",font=("Aerial",13))
btn7.grid(row=2,column=2)
btn8=Button(calc,text="/",width=5,height=2,bg="#1c81d9",fg="white",font=("Aerial",13,"bold"),command=lambda:press("/"))
btn8.grid(row=2,column=3)
btn9=Button(calc,text="7",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("7"))
btn9.grid(row=3,column=0)
btn10=Button(calc,text="8",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("8"))
btn10.grid(row=3,column=1)
btn11=Button(calc,text="9",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("9"))
btn11.grid(row=3,column=2)
btn12=Button(calc,text="x",width=5,height=2,bg="#1c81d9",fg="white",font=("Aerial",13,"bold"),command=lambda:press("*"))
btn12.grid(row=3,column=3)
btn13=Button(calc,text="4",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("4"))
btn13.grid(row=4,column=0)
btn14=Button(calc,text="5",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("5"))
btn14.grid(row=4,column=1)
btn15=Button(calc,text="6",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("6"))
btn15.grid(row=4,column=2)
btn16=Button(calc,text="-",width=5,height=2,bg="#1c81d9",fg="white",font=("Aerial",13,"bold"),command=lambda:press("-"))
btn16.grid(row=4,column=3)
btn17=Button(calc,text="1",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("1"))
btn17.grid(row=5,column=0)
btn18=Button(calc,text="2",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("2"))
btn18.grid(row=5,column=1)
btn19=Button(calc,text="3",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("3"))
btn19.grid(row=5,column=2)
btn19=Button(calc,text="+",width=5,height=2,bg="#1c81d9",fg="white",font=("Aerial",13,"bold"),command=lambda:press("+"))
btn19.grid(row=5,column=3)
btn20=Button(calc,text="+/-",width=5,height=2,bg="white",font=("Aerial",13))
btn20.grid(row=6,column=0)
btn21=Button(calc,text="0",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("0"))
btn21.grid(row=6,column=1)
btn22=Button(calc,text=".",width=5,height=2,bg="white",font=("Aerial",13),command=lambda:press("."))
btn22.grid(row=6,column=2)
btn23=Button(calc,text="=",width=5,height=2,bg="#eb1757",fg="white",font=("Aerial",13,"bold"),command=calculation)
btn23.grid(row=6,column=3)


calc.mainloop()