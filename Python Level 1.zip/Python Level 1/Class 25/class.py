#Theory Part Only



#below python version below 3, we have to install python SQLite 
#pip install sqlite