import assignment_add
import assignment_sub
import assingment_multi
import assignment_div

print("Use signs for actions.The actions valid are\n+\n-\n*\n/")
d=int(input("Enter the first number: "))
e=int(input("Enter the second number: "))
c=input("Enter the action: ")
if c=="+":
    assignment_add.add(d,e)
elif c=="-":
    assignment_sub.sub(d,e)
elif c=="/":
    assignment_div.div(d,e)
elif c=="*":
    assingment_multi.multi(d,e)
