def div(a,b):
    print(a,"/",b,"=",a/b)
