def multi(a,b):
    print(a,"x",b,"=", a*b)