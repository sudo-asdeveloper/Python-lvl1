from math import *
from random import *
from PyDictionary import PyDictionary
dictionary=PyDictionary()
print(factorial(7))
print(fmod(45,34))
print(gcd(464,478))
print(pow(7,2))
a=[33,43]
print(prod(a))
print(sqrt(54))
print(choice(a))
list1=["dgs","dgsd","dfds","vvdvv"]
print(choices(list1,weights=[5,3,1,0],k=12))
print(randrange(1,100))
print (dictionary.meaning("coding"))