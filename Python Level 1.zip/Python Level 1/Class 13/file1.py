def add(a,b):
    print(a+b)