num = int(input("Enter an odd integer between 4 and 10: "))
print(" "*(num+1)+str(num))
a=1
spc=num-1
for i in range(0, num):
    print(" "*spc+str(num-a)+" "*a+str(num)+" "*a+str(num+a))
    a+=1
    spc=spc-1