from tkinter import *
screen=Tk()
screen.geometry("500x500")
var=IntVar()
chk=Checkbutton(screen,text="Pepperoni",onvalue=1,offvalue=0,variable=var)
chk.pack()
def clik():
    if var.get()==1:
        lbl=Label(screen,text="You have choosen Pepperoni")
        lbl.pack()
    else:
        lbl=Label(screen,text="You have not choosen Pepperoni")
        lbl.pack()
btn=Button(screen,text="Select Toppings",command=clik)
btn.pack()
screen.mainloop()