from tkinter import *

screen=Tk()
screen.geometry("500x500")

c1=IntVar()
c2=IntVar()
c3=IntVar()
c4=IntVar()
chk1=Checkbutton(screen,text="HTML",onvalue=1,offvalue=0,variable=c1)
chk1.pack()
chk2=Checkbutton(screen,text="CSS",onvalue=1,offvalue=0,variable=c2)
chk2.pack()
chk3=Checkbutton(screen,text="JAVA",onvalue=1,offvalue=0,variable=c3)
chk3.pack()
chk4=Checkbutton(screen,text="PYTHON",onvalue=1,offvalue=0,variable=c4)
chk4.pack()

def clk():
    if c1.get()==1:
        lbl1=Label(screen,text="Checked 1")
        lbl1.pack()
    
    if c2.get()==1:
        lbl2=Label(screen,text="Checked 2")
        lbl2.pack()

    if c3.get()==1:
        lbl3=Label(screen,text="Checked 3")
        lbl3.pack()

    if c4.get()==1:
        lbl4=Label(screen,text="Checked 4")
        lbl4.pack()

btn1=Button(screen,text="Click Me!",command=clk)
btn1.pack()



screen.mainloop()