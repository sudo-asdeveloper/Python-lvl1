from tkinter import *
screen=Tk()
screen.geometry("500x500")
options=["Java","Python","C++","HTML","CSS"]
var=StringVar()
var.set("Choose a Language")
opt=OptionMenu(screen,var,*options)
opt.pack()
def clk():
    lbl1=Label(screen,text=var.get())
    lbl1.pack()
btn1=Button(screen,text="CLick ME!!",command=clk)
btn1.pack()
screen.mainloop()