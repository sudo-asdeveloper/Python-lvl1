import sqlite3
from tkinter import *
screen=Tk()
screen.geometry("500x500")

connection=sqlite3.connect("pass_manager.db")

curs_er=connection.cursor()

#Table="""CREATE TABLE manager(
#gmail varchar(100) primary key,
#password varchar(100)
#)"""


#curs_er.execute(Table)




def query():
    curs_er.execute("""select * from manager""")
    fetch=curs_er.fetchall()
    result=""
    for i in fetch:
        result+="Gmail : "+i[0]+"    ||    Password : "+i[1]+"\n"
    lbl6=Label(screen,text=result)
    lbl6.grid(row=9,columnspan=2)
    connection.commit()
    


lbl1=Label(screen,text="Gmail : ")
lbl1.grid(row=0,column=0)
txt1=Entry(screen)
txt1.grid(row=0,column=1)

lbl2=Label(screen,text="Password : ")
lbl2.grid(row=1,column=0)
txt2=Entry(screen)
txt2.grid(row=1,column=1)


def add():
    curs_er.execute("insert into manager values(:gmail,:password)",
                {
                    "gmail":txt1.get(),
                    "password":txt2.get()
                }    
                    )
    txt1.delete(0,END)

    txt2.delete(0,END)

    connection.commit()


btn1=Button(screen,text="Add record to Database",command=add)
btn1.grid(row=2,columnspan=2)

btn2=Button(screen,text="Query the Database",command=query)
btn2.grid(row=3,columnspan=2)

lbl7=Label(screen,text="Gmail : ")
lbl7.grid(row=4, column=0)

txt6=Entry(screen,text="")
txt6.grid(row=4,column=1)
def update():
    curs_er.execute("""update manager set gmail=:gmail,password=:password where gmail=:gmaill""",{
        "gmail":toptxt1.get(),
        "password":toptxt2.get(),
        "gmaill":txt6.get()
    })
def edit():
    top=Toplevel()
    top.geometry("500x500")
    top.title("Update")
    global txt6
    global toptxt1
    global toptxt2

    toplbl1=Label(top,text="Gmail : ")
    toplbl1.grid(row=0,column=0)
    topstaff_number=IntVar
    toptxt1=Entry(top,textvariable=topstaff_number)
    toptxt1.grid(row=0,column=1)

    toplbl2=Label(top,text="Password : ")
    toplbl2.grid(row=1,column=0)
    topstaff_fname=StringVar
    toptxt2=Entry(top,textvariable=topstaff_fname)
    toptxt2.grid(row=1,column=1)


    search=txt6.get()
    curs_er.execute("select * from manager where gmail=:gm",{
        "gm":search
        })
    search=curs_er.fetchall()
    for i in search:
        toptxt1.insert(0,i[0])
        toptxt2.insert(0,i[1])
    topbtn=Button(top,text="Update",command=update)
    topbtn.grid(row=5,column=0)


    top.mainloop()


btn3=Button(screen,text="Search",command=edit)
btn3.grid(row=8,column=0)

def dele():
    curs_er.execute("""delete from manager where gmail=:gm""",{
                    "gm":txt6.get()
                    })

btn4=Button(screen,text="Remove",command=dele)
btn4.grid(row=8,column=1)

screen.mainloop()